from flask import Flask, render_template, request, jsonify
import csv, os, re
from difflib import SequenceMatcher

app = Flask(__name__)
DATA_FILE = os.path.join(os.path.dirname(__file__), "movies.csv")

def load_movies():
    with open(DATA_FILE, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

MOVIES = load_movies()
AGE_ORDER = {"U": 0, "PG": 1, "12+": 2, "15+": 3, "18+": 4}

def allowed_rating(age):
    # Conservative illustrative filter. Always check the official local rating before viewing.
    if age < 13: return {"U"}
    if age < 16: return {"U", "PG", "12+"}
    if age < 18: return {"U", "PG", "12+", "15+"}
    return set(AGE_ORDER)

def words(text):
    return set(re.findall(r"[a-z0-9]+", (text or "").lower()))

def recommend(age, genre="", mood="", query="", limit=8):
    try: age = max(1, min(100, int(age)))
    except (ValueError, TypeError): age = 18
    safe_ratings = allowed_rating(age)
    genre, mood, query = genre.lower().strip(), mood.lower().strip(), query.lower().strip()
    results = []
    for movie in MOVIES:
        if movie["rating"] not in safe_ratings:
            continue
        score = 0.0
        genres = movie["genres"].lower()
        moods = movie["moods"].lower()
        searchable = " ".join([movie["title"], movie["genres"], movie["description"], movie["moods"]]).lower()
        if genre and genre in genres: score += 4
        if mood and mood in moods: score += 3
        if query:
            qwords = words(query)
            mw = words(searchable)
            score += 4 * (len(qwords & mw) / max(1, len(qwords)))
            score += SequenceMatcher(None, query, movie["title"].lower()).ratio()
        score += float(movie["rating_score"]) / 10
        results.append((score, movie))
    results.sort(key=lambda x: x[0], reverse=True)
    # If filters produce no exact matches, the safe age-filtered catalogue is still returned.
    return [m for _, m in results[:limit]]

@app.route("/")
def home():
    genres = sorted({g.strip() for m in MOVIES for g in m["genres"].split("|")})
    return render_template("index.html", genres=genres)

@app.route("/recommend", methods=["POST"])
def recommend_route():
    data = request.get_json(silent=True) or request.form
    age = data.get("age", 18)
    items = recommend(age, data.get("genre", ""), data.get("mood", ""), data.get("query", ""))
    return jsonify({"movies": items, "note": "Age filtering is an illustrative guide, not a guarantee of suitability. Check the official rating and content details."})

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "").strip()
    age = data.get("age", 18)
    text = message.lower()
    genres = ["animation", "adventure", "comedy", "drama", "sci-fi", "science fiction", "fantasy", "action", "mystery", "family"]
    moods = ["happy", "feel-good", "romantic", "thoughtful", "excited", "curious", "inspired", "relaxed", "adventurous"]
    genre = next((g for g in genres if g in text), "")
    if genre == "science fiction": genre = "sci-fi"
    mood = next((m for m in moods if m in text), "")
    items = recommend(age, genre, mood, message, limit=5)
    if not items:
        reply = "I couldn't find a match in this small demo catalogue. Try another genre or mood."
    else:
        titles = ", ".join(m["title"] for m in items[:5])
        reply = f"Based on your age setting and request, try: {titles}. I filtered using the demo's age-rating labels; please verify official local ratings and content warnings."
    return jsonify({"reply": reply, "movies": items})

if __name__ == "__main__":
    app.run(debug=True)
