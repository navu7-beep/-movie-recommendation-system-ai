# CineAI — Age-aware Movie Recommendation Demo

A small Flask web app that recommends movies using age setting, genre, mood, and a simple content-matching score. Includes a conversational demo assistant.

## Run on Windows (VS Code / PowerShell)
1. Install Python 3.10+.
2. Open this folder in VS Code.
3. In the terminal, run:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   python app.py
   ```
   If PowerShell blocks activation, you can skip activation and run:
   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   .\.venv\Scripts\python.exe app.py
   ```
4. Open `http://127.0.0.1:5000` in your browser.

## How it works
- A bundled sample catalogue (`movies.csv`) keeps the project runnable without downloading a dataset.
- Recommendations score matches for genre, mood, search terms, and rating score.
- The chat assistant extracts a few genre/mood keywords and uses the same recommendation function. It is a demo assistant, not a large language model.
- Movie posters load from TMDB image URLs and need an internet connection; if a poster fails, the movie card still shows its title.

## Important limitations
- Age labels in `movies.csv` are illustrative demo labels, not verified official Indian certification ratings. The age filter is only a starting point, not a safety guarantee. Before using this for real users, replace labels with verified ratings for the relevant country and add content advisories.
- This starter version does not learn long-term preferences or use an external generative-AI API. Those can be added later.
